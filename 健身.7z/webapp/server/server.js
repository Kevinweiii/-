import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import http from 'http';
import { WebSocketServer } from 'ws';
import { spawn } from 'child_process';
import dotenv from 'dotenv';

// 載入環境變數
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

// 創建 HTTP 服務器
const server = http.createServer(app);
// 設置 WebSocket 服務器
const wss = new WebSocketServer({ server });
// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// 新增 JSON body 解析中介層
app.use(express.json());

// 啟用 CORS: 允許所有來源
app.use(cors());

// WebSocket 連接處理
wss.on('connection', (ws) => {
    console.log('WebSocket 客戶端已連接');
    
    ws.on('message', (message) => {
        let data;
        try {
            data = JSON.parse(message);
        } catch (err) {
            ws.send(JSON.stringify({ type: 'error', message: '無效的 JSON' }));
            return;
        }
        
        const { prompt } = data;
        if (!prompt) {
            ws.send(JSON.stringify({ type: 'error', message: '未提供 prompt' }));
            return;
        }

        // 告知前端開始接收串流
        ws.send(JSON.stringify({ type: 'start' }));

        // 呼叫 callAzureOpenAI.js 並傳入 prompt
        const scriptPath = path.join(__dirname, '../callAzureOpenAI.js');
        const child = spawn('node', [scriptPath, prompt]);

        // 接收子程序 stdout 串流內容
        child.stdout.on('data', (chunk) => {
            const text = chunk.toString();
            ws.send(JSON.stringify({ type: 'chunk', delta: text }));
        });

        child.stderr.on('data', (chunk) => {
            console.error(`子進程錯誤: ${chunk.toString()}`);
            ws.send(JSON.stringify({ type: 'error', message: '處理請求時發生錯誤' }));
        });

        child.on('close', (code) => {
            ws.send(JSON.stringify({ type: 'end' }));
            console.log(`子進程結束，退出碼: ${code}`);
        });
    });

    ws.on('close', () => {
        console.log('WebSocket 客戶端已斷開連接');
    });
});

// 提供 azure_api.md 給前端讀取
app.get('/azure_api.md', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../azure_api.md'));
});

// 使用 server 而不是 app 來監聽
server.listen(port, () => {
    console.log(`伺服器運行於 http://localhost:${port}`);
}); 