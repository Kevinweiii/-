import dotenv from 'dotenv';
dotenv.config();
// 改用官方 'openai' 套件
import OpenAI from 'openai';

const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
const azureApiKey = process.env.AZURE_OPENAI_KEY;
const deploymentName = process.env.AZURE_OPENAI_DEPLOYMENT_NAME; // 請確保這是您的部署名稱

if (!endpoint || !azureApiKey || !deploymentName) {
  console.error("請確認 .env 檔案中已設定 AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_KEY, 和 AZURE_OPENAI_DEPLOYMENT_NAME");
  process.exit(1);
}

// 為 Azure 初始化 OpenAI client
// 注意：您可能需要根據您的 Azure OpenAI 設定調整 api-version
const client = new OpenAI({
  apiKey: azureApiKey,
  baseURL: `${endpoint}openai/deployments/${deploymentName}`,
  defaultQuery: { 'api-version': '2023-05-15' }, // 或其他您使用的 API 版本
  defaultHeaders: { 'api-key': azureApiKey },
});


async function callAzureOpenAI(prompt) {
  console.log(`正在傳送 prompt 到 Azure OpenAI (${deploymentName})...`);
  try {
    // 使用 client.chat.completions.create 進行流式傳輸
    const stream = await client.chat.completions.create({
        model: deploymentName, // 標準 client 需要 model 參數
        messages: [
            { role: "system", content: `你是一位專業的AI運動規劃師和健身教練，具備豐富的運動科學、營養學和訓練經驗。

你的職責是：
1. 根據使用者的個人資訊（年齡、性別、身高、體重、健康狀況、運動目標等）制定個人化的運動計畫
2. 提供專業的健身建議、運動技巧和安全指導
3. 給出合理的飲食建議以配合運動目標
4. 回答各種運動和健康相關的問題

回應要求：
- 使用繁體中文回答
- 提供具體、實用、可執行的建議
- 考慮使用者的個人差異和限制
- 強調安全性和循序漸進的原則
- 語氣要專業但親切，具有鼓勵性
- 如果涉及健康問題，建議使用者諮詢專業醫師

當制定運動計畫時，請包含：
1. 運動類型和強度建議
2. 詳細的週訓練安排
3. 適當的休息和恢復計畫
4. 進度追蹤方式
5. 飲食配合建議
6. 注意事項和安全提醒` },
            { role: "user", content: prompt },
        ],
        stream: true,
    });

    let fullResponse = "";
    console.log("\nAzure OpenAI 回應:");
    for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content || "";
        process.stdout.write(delta); // 流式輸出
        fullResponse += delta;
    }
    console.log("\n--- 回應結束 ---");
    return fullResponse;
  } catch (error) {
    // 提供更詳細的錯誤輸出
    console.error("\n呼叫 Azure OpenAI API 時發生錯誤:");
    if (error instanceof OpenAI.APIError) {
      console.error(`  狀態碼: ${error.status}`);
      console.error(`  回應標頭: ${JSON.stringify(error.headers)}`);
      console.error(`  錯誤回應: ${JSON.stringify(error.error)}`);
    } else {
      console.error(error);
    }
    return null;
  }
}

// --- 主程式執行 ---
async function main() {
  // 從命令列參數獲取 prompt，如果沒有提供，則使用英文預設值
  const userPrompt = process.argv[2] || "介紹你自己"; 

  if (!userPrompt) {
    console.log("用法: node callAzureOpenAI.js \"您的 prompt\"");
    return;
  }
  console.log('>>>>>', userPrompt);
  await callAzureOpenAI(userPrompt);
}

main(); 