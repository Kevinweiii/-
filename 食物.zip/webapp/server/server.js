import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';
import http from 'http';
import { WebSocketServer } from 'ws';
import { spawn } from 'child_process';
import dotenv from 'dotenv';
// 導入食物推薦系統
import { generatePersonalizedRecommendation, FoodRecommendationSystem } from '../foodRecommendation.js';

// 載入環境變數
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

// 創建 HTTP 服務器
const server = http.createServer(app);
// 設置 WebSocket 服務器
const wss = new WebSocketServer({ server });
// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// 新增 JSON body 解析中介層
app.use(express.json());

// 啟用 CORS: 允許所有來源
app.use(cors());

// 創建食物推薦系統實例
const foodRecommendationSystem = new FoodRecommendationSystem();

// 內容過濾系統
function filterInappropriateContent(prompt) {
    // 不當內容關鍵詞列表
    const inappropriateKeywords = [
        '屎', '糞', '尿', '吐', '嘔', '噁心', '髒', '垃圾', '廢物',
        '毒', '腐爛', '發霉', '變質', '臭', '惡臭',
        // 添加更多需要過濾的關鍵詞
        'shit', 'poop', 'toilet', 'vomit', 'garbage', 'trash',
        'rotten', 'disgusting', 'filthy'
    ];
    
    const promptLower = prompt.toLowerCase();
    
    // 檢查是否包含不當內容
    const hasInappropriateContent = inappropriateKeywords.some(keyword => 
        promptLower.includes(keyword)
    );
    
    if (hasInappropriateContent) {
        return {
            isFiltered: true,
            reason: '內容包含不當關鍵詞',
            suggestion: '建議使用正當的食物相關詞彙，例如：推薦健康美食、營養餐點等'
        };
    }
    
    // 檢查是否為過短或無意義的輸入
    if (prompt.trim().length < 2) {
        return {
            isFiltered: true,
            reason: '輸入內容過短',
            suggestion: '請描述您想要的食物類型或推薦需求'
        };
    }
    
    return {
        isFiltered: false,
        content: prompt
    };
}

// 生成建議回應
function generateSuggestedResponses() {
    const suggestions = [
        "🍎 推薦一些健康的水果餐點",
        "🥗 我想要營養均衡的沙拉推薦", 
        "🍜 給我一些溫暖的湯品建議",
        "🥘 推薦適合家庭聚餐的料理",
        "🍓 我想要美味的甜點推薦"
    ];
    
    return suggestions[Math.floor(Math.random() * suggestions.length)];
}

// 檢測是否為食物推薦相關的請求
function isFoodRecommendationRequest(prompt) {
    const foodKeywords = [
        '推薦', '食物', '美食', '料理', '餐點', '菜單', '吃什麼', '食譜',
        '早餐', '午餐', '晚餐', '點心', '零食', '宵夜',
        '健康', '營養', '減肥', '增重', '素食',
        '心情', '天氣', '快速', '簡單', '特殊場合',
        '療癒', '舒適', '溫暖', '清爽',
        // 新增湯品相關關鍵詞
        '湯', '雞湯', '心靈雞湯', '牛肉湯', '蔬菜湯', '湯品',
        '飲品', '喝什麼', '茶', '咖啡', '果汁', '奶茶',
        // 英文關鍵詞
        'food', 'meal', 'recipe', 'recommend', 'breakfast', 'lunch', 'dinner',
        'soup', 'drink', 'tea', 'coffee'
    ];
    
    const promptLower = prompt.toLowerCase();
    return foodKeywords.some(keyword => promptLower.includes(keyword));
}

// WebSocket 連接處理
wss.on('connection', (ws) => {
    console.log('🔗 WebSocket 客戶端已連接');
    
    // 設置連接保活
    ws.isAlive = true;
    
    // 處理 pong 回應
    ws.on('pong', () => {
        ws.isAlive = true;
    });
    
    ws.on('message', async (message) => {
        // 處理心跳消息
        if (message.toString() === 'ping') {
            console.log('💓 收到心跳，回應 pong');
            ws.send('pong');
            return;
        }

        let data;
        try {
            data = JSON.parse(message);
        } catch (err) {
            ws.send(JSON.stringify({ type: 'error', message: '無效的 JSON' }));
            return;
        }
        
        const { prompt } = data;
        if (!prompt) {
            ws.send(JSON.stringify({ type: 'error', message: '未提供 prompt' }));
            return;
        }

        console.log(`📝 收到用戶請求 (${prompt.length} 字符)`);

        // 內容過濾檢查
        const filterResult = filterInappropriateContent(prompt);
        if (filterResult.isFiltered) {
            console.log(`🚫 內容被過濾: ${filterResult.reason}`);
            
            // 發送過濾警告和建議
            ws.send(JSON.stringify({ type: 'start' }));
            
            const warningMessage = `🚫 **內容安全提醒**

很抱歉，您的輸入包含不當內容，已被系統過濾。

**過濾原因：** ${filterResult.reason}

**建議：** ${filterResult.suggestion}

**推薦嘗試：** ${generateSuggestedResponses()}

🍽️ 我們的AI美食助手專門為您提供健康、美味的食物推薦。請使用正當的食物相關詞彙來獲得最佳的推薦體驗！`;

            // 模擬打字效果發送警告消息
            const chars = warningMessage.split('');
            for (let i = 0; i < chars.length; i++) {
                setTimeout(() => {
                    ws.send(JSON.stringify({ type: 'chunk', delta: chars[i] }));
                    if (i === chars.length - 1) {
                        ws.send(JSON.stringify({ type: 'end' }));
                    }
                }, i * 20);
            }
            return;
        }

        // 告知前端開始接收串流
        ws.send(JSON.stringify({ type: 'start' }));

        try {
            // 檢查是否為食物推薦請求
            if (isFoodRecommendationRequest(prompt)) {
                console.log('🍽️ 識別為食物推薦請求，使用專門的推薦系統');
                
                // 使用專門的食物推薦系統，傳遞WebSocket參數
                try {
                    await generatePersonalizedRecommendation(prompt, {}, ws);
                    ws.send(JSON.stringify({ type: 'end' }));
                } catch (error) {
                    console.error('食物推薦錯誤:', error);
                    ws.send(JSON.stringify({ type: 'error', message: '食物推薦系統暫時無法使用' }));
                }
                
            } else {
                console.log('💬 使用通用對話系統');
                // 使用原有的通用對話系統
                const scriptPath = path.join(__dirname, '../callAzureOpenAI.js');
                const child = spawn('node', [scriptPath, prompt]);

                // 接收子程序 stdout 串流內容
                child.stdout.on('data', (chunk) => {
                    const text = chunk.toString();
                    ws.send(JSON.stringify({ type: 'chunk', delta: text }));
                });

                child.stderr.on('data', (chunk) => {
                    console.error(`子進程錯誤: ${chunk.toString()}`);
                    ws.send(JSON.stringify({ type: 'error', message: '處理請求時發生錯誤' }));
                });

                child.on('close', (code) => {
                    ws.send(JSON.stringify({ type: 'end' }));
                    console.log(`子進程結束，退出碼: ${code}`);
                });
            }
        } catch (error) {
            console.error('處理請求時發生錯誤:', error);
            ws.send(JSON.stringify({ type: 'error', message: '服務器內部錯誤' }));
        }
    });

    ws.on('close', () => {
        console.log('🔌 WebSocket 客戶端已斷開連接');
    });

    ws.on('error', (error) => {
        console.error('WebSocket 錯誤:', error);
    });
});

// API 路由：獲取食物推薦
app.get('/api/food-recommendations/:type', (req, res) => {
    try {
        const { type } = req.params;
        let recommendations;

        switch (type) {
            case 'random':
                recommendations = foodRecommendationSystem.getRandomRecommendations();
                break;
            case 'healthy':
                recommendations = foodRecommendationSystem.getHealthyRecommendations();
                break;
            case 'quick':
                recommendations = foodRecommendationSystem.getQuickMeals();
                break;
            case 'breakfast':
                recommendations = foodRecommendationSystem.getRecommendationsByType('breakfast');
                break;
            case 'lunch':
                recommendations = foodRecommendationSystem.getRecommendationsByType('lunch');
                break;
            case 'dinner':
                recommendations = foodRecommendationSystem.getRecommendationsByType('dinner');
                break;
            case 'snacks':
                recommendations = foodRecommendationSystem.getRecommendationsByType('snacks');
                break;
            default:
                recommendations = foodRecommendationSystem.getRandomRecommendations();
        }

        res.json({
            success: true,
            type: type,
            recommendations: recommendations,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('API 食物推薦錯誤:', error);
        res.status(500).json({
            success: false,
            error: '無法獲取食物推薦'
        });
    }
});

// API 路由：根據心情推薦食物
app.get('/api/food-recommendations/mood/:mood', (req, res) => {
    try {
        const { mood } = req.params;
        const recommendations = foodRecommendationSystem.getRecommendationsByMood(mood);
        
        res.json({
            success: true,
            mood: mood,
            recommendations: recommendations,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('心情推薦錯誤:', error);
        res.status(500).json({
            success: false,
            error: '無法獲取心情推薦'
        });
    }
});

// API 路由：根據天氣推薦食物
app.get('/api/food-recommendations/weather/:weather', (req, res) => {
    try {
        const { weather } = req.params;
        const recommendations = foodRecommendationSystem.getRecommendationsByWeather(weather);
        
        res.json({
            success: true,
            weather: weather,
            recommendations: recommendations,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('天氣推薦錯誤:', error);
        res.status(500).json({
            success: false,
            error: '無法獲取天氣推薦'
        });
    }
});

// 提供 azure_api.md 給前端讀取
app.get('/azure_api.md', (req, res) => {
  res.sendFile(path.resolve(__dirname, '../azure_api.md'));
});

// 健康檢查端點
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        services: {
            webSocket: 'active',
            foodRecommendation: 'active',
            azureOpenAI: 'configured'
        }
    });
});

// WebSocket 心跳檢測 - 每30秒檢查一次連接狀態
const heartbeatInterval = setInterval(() => {
    wss.clients.forEach((ws) => {
        if (ws.isAlive === false) {
            console.log('💔 檢測到失活連接，正在終止');
            return ws.terminate();
        }

        ws.isAlive = false;
        ws.ping(); // 發送 ping
    });
}, 30000); // 30秒間隔

// 清理心跳定時器
wss.on('close', () => {
    clearInterval(heartbeatInterval);
});

// 使用 server 而不是 app 來監聽
server.listen(port, () => {
    console.log(`🚀 伺服器運行於 http://localhost:${port}`);
    console.log(`🍽️  食物推薦系統已啟動`);
    console.log(`🤖 Azure OpenAI 整合已準備就緒`);
    console.log(`💓 WebSocket 心跳機制已啟動 (30秒間隔)`);
}); 