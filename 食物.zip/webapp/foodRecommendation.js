import dotenv from 'dotenv';
import OpenAI from 'openai';

dotenv.config();

const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
const azureApiKey = process.env.AZURE_OPENAI_KEY;
const deploymentName = process.env.AZURE_OPENAI_DEPLOYMENT_NAME;

// 檢查Azure OpenAI配置是否完整
const isAzureConfigured = endpoint && azureApiKey && deploymentName;
let client = null;

if (isAzureConfigured) {
  try {
    // 為 Azure 初始化 OpenAI client
    client = new OpenAI({
      apiKey: azureApiKey,
      baseURL: `${endpoint}openai/deployments/${deploymentName}`,
      defaultQuery: { 'api-version': '2023-05-15' },
      defaultHeaders: { 'api-key': azureApiKey },
    });
    console.log('✅ Azure OpenAI 配置已載入');
  } catch (error) {
    console.warn('⚠️ Azure OpenAI 初始化失敗，將使用本地推薦引擎:', error.message);
    client = null;
  }
} else {
  console.log('ℹ️ 未檢測到完整的 Azure OpenAI 配置，使用本地推薦引擎');
  console.log('💡 如需使用 AI 推薦，請參考 SETUP_GUIDE.md 設置 Azure OpenAI');
}

// 食物推薦數據庫
const foodDatabase = {
  breakfast: [
    { name: "燕麥粥配水果", calories: 250, prep_time: "10分鐘", healthy: true, ingredients: ["燕麥", "牛奶", "香蕉", "藍莓"] },
    { name: "蔬菜蛋餅", calories: 300, prep_time: "15分鐘", healthy: true, ingredients: ["雞蛋", "菠菜", "番茄", "起司"] },
    { name: "酪梨吐司", calories: 280, prep_time: "5分鐘", healthy: true, ingredients: ["全麥吐司", "酪梨", "海鹽", "檸檬"] },
    { name: "希臘優格配堅果", calories: 200, prep_time: "3分鐘", healthy: true, ingredients: ["希臘優格", "核桃", "蜂蜜", "草莓"] }
  ],
  lunch: [
    { name: "雞胸沙拉", calories: 350, prep_time: "20分鐘", healthy: true, ingredients: ["雞胸肉", "生菜", "番茄", "橄欖油"] },
    { name: "鮭魚飯糰", calories: 400, prep_time: "25分鐘", healthy: true, ingredients: ["鮭魚", "白米", "紫菜", "黃瓜"] },
    { name: "蔬菜義大利麵", calories: 380, prep_time: "30分鐘", healthy: true, ingredients: ["全麥義大利麵", "櫛瓜", "番茄", "蒜頭"] },
    { name: "牛肉麵", calories: 450, prep_time: "45分鐘", healthy: false, ingredients: ["牛肉", "麵條", "青菜", "高湯"] }
  ],
  dinner: [
    { name: "檸檬香草烤魚", calories: 320, prep_time: "35分鐘", healthy: true, ingredients: ["白魚", "檸檬", "迷迭香", "橄欖油"] },
    { name: "蒸蛋配蔬菜", calories: 250, prep_time: "20分鐘", healthy: true, ingredients: ["雞蛋", "花椰菜", "紅蘿蔔", "香菇"] },
    { name: "紅燒豬肉", calories: 480, prep_time: "60分鐘", healthy: false, ingredients: ["豬肉", "醬油", "冰糖", "薑"] },
    { name: "蔬菜咖哩", calories: 300, prep_time: "40分鐘", healthy: true, ingredients: ["馬鈴薯", "紅蘿蔔", "咖哩粉", "椰奶"] }
  ],
  snacks: [
    { name: "堅果優格杯", calories: 180, prep_time: "5分鐘", healthy: true, ingredients: ["優格", "杏仁", "蜂蜜"] },
    { name: "蘋果花生醬", calories: 220, prep_time: "3分鐘", healthy: true, ingredients: ["蘋果", "花生醬"] },
    { name: "蒸地瓜", calories: 160, prep_time: "30分鐘", healthy: true, ingredients: ["地瓜"] },
    { name: "蔬菜棒配沾醬", calories: 120, prep_time: "10分鐘", healthy: true, ingredients: ["胡蘿蔔", "黃瓜", "鷹嘴豆泥"] }
  ],
  comfort: [
    { name: "雞湯", calories: 200, prep_time: "60分鐘", healthy: true, ingredients: ["雞肉", "薑", "蔥", "鹽"] },
    { name: "熱可可", calories: 150, prep_time: "10分鐘", healthy: false, ingredients: ["可可粉", "牛奶", "糖"] },
    { name: "粥配鹹菜", calories: 180, prep_time: "45分鐘", healthy: true, ingredients: ["白米", "鹹菜", "肉絲"] },
    { name: "蒸蛋羹", calories: 120, prep_time: "15分鐘", healthy: true, ingredients: ["雞蛋", "溫水", "蔥花"] }
  ]
};

// 根據心情的食物推薦
const moodFoodMapping = {
  happy: ["色彩豐富的沙拉", "彩虹水果拼盤", "清爽義大利麵"],
  sad: ["溫暖雞湯", "熱可可", "舒芙蕾鬆餅"],
  stressed: ["燕麥粥", "香蕉", "堅果類食物"],
  energetic: ["蛋白質豐富的料理", "牛排", "能量果昔"],
  tired: ["維生素B群食物", "深色綠葉蔬菜", "優質蛋白質"],
  romantic: ["精緻義大利料理", "紅酒配起司", "朱古力甜點"]
};

// 根據天氣的食物推薦
const weatherFoodMapping = {
  hot: ["涼拌菜", "冰沙", "清爽沙拉", "冷湯"],
  cold: ["熱湯", "火鍋", "燉菜", "熱飲"],
  rainy: ["舒適食物", "熱茶", "湯麵", "烘培食物"],
  sunny: ["戶外燒烤", "新鮮水果", "輕食", "冰品"]
};

// 智能食物推薦系統
export class FoodRecommendationSystem {
  constructor() {
    this.preferences = new Map();
    this.history = [];
  }

  // 根據類型獲取推薦
  getRecommendationsByType(type) {
    if (foodDatabase[type]) {
      return this.shuffleArray(foodDatabase[type]).slice(0, 3);
    }
    return [];
  }

  // 根據心情推薦
  getRecommendationsByMood(mood) {
    const foods = moodFoodMapping[mood.toLowerCase()] || [];
    return foods;
  }

  // 根據天氣推薦
  getRecommendationsByWeather(weather) {
    const foods = weatherFoodMapping[weather.toLowerCase()] || [];
    return foods;
  }

  // 健康推薦
  getHealthyRecommendations() {
    const allHealthy = [];
    Object.values(foodDatabase).forEach(category => {
      allHealthy.push(...category.filter(food => food.healthy));
    });
    return this.shuffleArray(allHealthy).slice(0, 5);
  }

  // 快速料理推薦
  getQuickMeals() {
    const allFoods = [];
    Object.values(foodDatabase).forEach(category => {
      allFoods.push(...category);
    });
    return allFoods
      .filter(food => parseInt(food.prep_time) <= 30)
      .sort((a, b) => parseInt(a.prep_time) - parseInt(b.prep_time))
      .slice(0, 5);
  }

  // 隨機推薦
  getRandomRecommendations() {
    const allFoods = [];
    Object.values(foodDatabase).forEach(category => {
      allFoods.push(...category);
    });
    return this.shuffleArray(allFoods).slice(0, 3);
  }

  // 工具方法：數組隨機排序
  shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  }

  // 生成詳細推薦文本 - 強制條列式格式
  generateRecommendationText(foods, context = '') {
    let text = `### 📋 **需求分析**\n`;
    text += `- 用戶尋求${context}的美食建議\n`;
    text += `- 系統提供營養均衡且美味的選擇\n\n`;
    
    text += `### 🍽️ **推薦清單**\n\n`;
    
    foods.forEach((food, index) => {
      const emoji = ['1️⃣', '2️⃣', '3️⃣'][index] || `${index + 1}️⃣`;
      
      if (typeof food === 'string') {
        text += `#### ${emoji} **${food}**\n`;
        text += `- **簡介：** 經典美味料理，值得品嚐\n`;
        text += `- **營養價值：** 均衡營養搭配\n`;
        text += `- **製作時間：** 適中\n`;
        text += `- **適合原因：** 口感佳，營養豐富\n`;
        text += `- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=${encodeURIComponent(food)}+製作方法)\n\n`;
      } else {
        text += `#### ${emoji} **${food.name}**\n`;
        text += `- **簡介：** 精心調配的營養料理，口感層次豐富\n`;
        text += `- **營養價值：** 熱量${food.calories}卡，${food.healthy ? '健康低脂' : '美味豐富'}\n`;
        text += `- **製作時間：** ${food.prep_time}\n`;
        text += `- **適合原因：** 營養密度高，製作簡便，適合日常享用\n`;
        text += `- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=${encodeURIComponent(food.name)}+製作方法)\n\n`;
      }
    });

    text += `### 💡 **額外建議**\n\n`;
    text += `#### 🍞 **搭配建議**\n`;
    text += `- 可以搭配溫開水或無糖茶飲\n`;
    text += `- 建議加入時令蔬菜增加纖維攝取\n\n`;
    
    text += `#### 🌶️ **調味建議**\n`;
    text += `- 使用天然香料和新鮮香草提味\n`;
    text += `- 控制鹽分攝取，多用檸檬汁調味\n\n`;
    
    text += `#### 🥬 **營養建議**\n`;
    text += `- 注意營養均衡，蛋白質、碳水化合物、脂肪比例合理\n`;
    text += `- 每日攝取充足的蔬菜和水果\n`;

    return text;
  }
}

// 超嚴格格式驗證函數
function validateListFormat(text) {
  if (!text || typeof text !== 'string') {
    console.log('❌ 文本為空或格式錯誤');
    return false;
  }
  
  console.log('🔍 開始格式驗證...');
  const lines = text.split('\n');
  
  // 檢查必要的標題
  const requiredTitles = [
    /###.*需求分析/,
    /###.*推薦清單/,
    /###.*額外建議/
  ];
  
  for (let i = 0; i < requiredTitles.length; i++) {
    if (!text.match(requiredTitles[i])) {
      console.log(`❌ 缺少必要標題: ${['需求分析', '推薦清單', '額外建議'][i]}`);
      return false;
    }
  }
  
  // 檢查推薦項目編號
  const requiredItems = [/####.*1️⃣/, /####.*2️⃣/, /####.*3️⃣/];
  for (let i = 0; i < requiredItems.length; i++) {
    if (!text.match(requiredItems[i])) {
      console.log(`❌ 缺少編號推薦項目: ${i + 1}️⃣`);
      return false;
    }
  }
  
  // 檢查每個推薦項目是否有五個必要子項目
  const requiredSubItems = ['簡介：', '營養價值：', '製作時間：', '適合原因：', '製作影片：'];
  for (const subItem of requiredSubItems) {
    const pattern = new RegExp(`\\*\\*${subItem}\\*\\*`, 'g');
    const matches = text.match(pattern);
    if (!matches || matches.length < 3) {
      console.log(`❌ 子項目「${subItem}」出現次數不足 (需要3次，實際${matches ? matches.length : 0}次)`);
      return false;
    }
  }
  
  // 超嚴格條列式檢查 - 95%以上的內容行必須是條列式
  let contentLines = 0;
  let bulletLines = 0;
  let problematicLines = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // 跳過空行
    if (line === '') continue;
    
    // 跳過標題行
    if (line.startsWith('###') || line.startsWith('####')) continue;
    
    contentLines++;
    
    if (line.startsWith('-')) {
      bulletLines++;
    } else {
      problematicLines.push(`第${i + 1}行: "${line}"`);
    }
  }
  
  const bulletRatio = contentLines > 0 ? bulletLines / contentLines : 0;
  
  if (bulletRatio < 0.95) {
    console.log(`❌ 條列式格式嚴重不足: ${Math.round(bulletRatio * 100)}% (需要>=95%)`);
    console.log('❌ 問題行:', problematicLines.slice(0, 5));
    return false;
  }
  
  // 檢查是否有段落形式的文字（超過100字的行）
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.length > 100 && !line.startsWith('#')) {
      console.log(`❌ 第${i + 1}行過長，疑似段落形式: "${line.substring(0, 50)}..."`);
      return false;
    }
  }
  
  console.log('✅ 超嚴格格式驗證通過');
  console.log(`📊 統計: 內容行${contentLines}行，條列式${bulletLines}行，比例${Math.round(bulletRatio * 100)}%`);
  return true;
}

// 使用Azure OpenAI生成個性化推薦
export async function generatePersonalizedRecommendation(prompt, userContext = {}, websocket = null) {
  const foodSystem = new FoodRecommendationSystem();
  
  // 如果沒有Azure OpenAI配置，直接使用本地推薦引擎
  if (!client || !isAzureConfigured) {
    console.log('🔄 使用本地智能推薦引擎...');
    return await generateLocalRecommendation(prompt, foodSystem, websocket);
  }
  
  // 極嚴格條列式格式系統提示詞
  const systemPrompt = `你是專業美食推薦師，必須嚴格遵循條列式格式。

!!!!!!! 絕對強制條列式格式 !!!!!!!
注意：除了標題行（# 開頭），所有其他行都必須以「-」開始！

格式要求：
1. 只能有 ### 和 #### 標題
2. 除標題外，每行都必須以「-」開始
3. 絕對禁止段落形式
4. 絕對禁止長句
5. 每行最多50個字符

強制格式範本（完全照抄）：
### 📋 **需求分析**
- 分析用戶的具體需求
- 識別關鍵營養要求

### 🍽️ **推薦清單**

#### 1️⃣ **料理名稱一**
- **簡介：** 簡單描述
- **營養價值：** 營養資訊
- **製作時間：** 時間說明
- **適合原因：** 推薦理由
- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=料理名稱一+製作方法)

#### 2️⃣ **料理名稱二**
- **簡介：** 簡單描述
- **營養價值：** 營養資訊
- **製作時間：** 時間說明
- **適合原因：** 推薦理由
- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=料理名稱二+製作方法)

#### 3️⃣ **料理名稱三**
- **簡介：** 簡單描述
- **營養價值：** 營養資訊
- **製作時間：** 時間說明
- **適合原因：** 推薦理由
- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=料理名稱三+製作方法)

### 💡 **額外建議**

#### 🍞 **搭配建議**
- 第一個搭配建議
- 第二個搭配建議

#### 🌶️ **調味建議**
- 第一個調味建議
- 第二個調味建議

#### 🥬 **營養建議**
- 第一個營養建議
- 第二個營養建議

!!!!!!! 檢查規則 !!!!!!!
❌ 禁止：任何不以「-」開始的行（標題除外）
❌ 禁止：段落形式文字
❌ 禁止：超過50字的長句
❌ 禁止：沒有編號的推薦
✅ 必須：每行都以「-」開始
✅ 必須：三個主要章節
✅ 必須：三個編號推薦
✅ 必須：五個子項目（簡介、營養價值、製作時間、適合原因、製作影片）

重要：製作影片必須是 YouTube 連結格式：
- **製作影片：** [YouTube 製作教學](https://www.youtube.com/results?search_query=料理名稱+製作方法)

!!!!!!! 格式錯誤將重新生成 !!!!!!!`;

  try {
    console.log('🤖 正在使用 Azure OpenAI 生成個性化推薦...');
    
    // 使用非串流模式先生成完整回應，然後驗證格式
    const response = await client.chat.completions.create({
      model: deploymentName,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt },
      ],
      stream: false,
      temperature: 0.7,
      max_tokens: 1500,
    });
    
    let fullResponse = response.choices[0]?.message?.content || "";
    
    // 格式驗證
    const isValidFormat = validateListFormat(fullResponse);
    
         if (!isValidFormat) {
       console.log('⚠️ 格式驗證失敗，重新生成...');
       
       // 重新生成更嚴格的回應
       const retryResponse = await client.chat.completions.create({
         model: deploymentName,
         messages: [
           { role: "system", content: systemPrompt + `

!!!!! 緊急格式修正 !!!!!
前一次回應格式不正確。必須完全按照條列式格式。
每一行都必須以「-」開始（除了標題行）。
絕對不能有段落形式的文字。
如果再次格式錯誤，將切換到本地推薦系統。` },
           { role: "user", content: prompt + "\n\n請確保使用完全條列式格式，每行都要有「-」符號" },
         ],
         stream: false,
         temperature: 0.3, // 大幅降低溫度
         max_tokens: 1500,
       });
       
       const retryText = retryResponse.choices[0]?.message?.content || "";
       
       // 再次驗證格式
       if (validateListFormat(retryText)) {
         fullResponse = retryText;
         console.log('✅ 重新生成成功，格式正確');
       } else {
         console.log('❌ 重新生成仍然失敗，強制使用本地推薦系統');
         fullResponse = await generateLocalRecommendation(prompt, new FoodRecommendationSystem(), null);
       }
     }
    
    // 模擬串流輸出
    if (websocket) {
      const words = fullResponse.split('');
      for (let i = 0; i < words.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 20)); // 打字效果
        websocket.send(JSON.stringify({ type: 'chunk', delta: words[i] }));
      }
    } else {
      console.log(fullResponse);
    }
    
    return fullResponse;
  } catch (error) {
    console.error('Azure OpenAI 調用錯誤:', error);
    console.log('🔄 切換到本地推薦引擎...');
    
    // 如果API調用失敗，使用本地推薦系統作為備選
    return await generateLocalRecommendation(prompt, foodSystem, websocket);
  }
}

// 本地推薦引擎
async function generateLocalRecommendation(prompt, foodSystem, websocket) {
  let fallbackResponse = "";
  let recommendationType = "智能推薦";
  
  // 智能分析用戶需求
  if (prompt.includes('心情') || prompt.includes('mood')) {
    const recommendations = foodSystem.getRecommendationsByMood('happy');
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '心情推薦');
    recommendationType = "心情推薦";
  } else if (prompt.includes('健康') || prompt.includes('營養')) {
    const recommendations = foodSystem.getHealthyRecommendations();
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '健康推薦');
    recommendationType = "健康推薦";
  } else if (prompt.includes('快速') || prompt.includes('簡單')) {
    const recommendations = foodSystem.getQuickMeals();
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '快速料理');
    recommendationType = "快速料理";
  } else if (prompt.includes('早餐')) {
    const recommendations = foodSystem.getRecommendationsByType('breakfast');
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '早餐推薦');
    recommendationType = "早餐推薦";
  } else if (prompt.includes('午餐')) {
    const recommendations = foodSystem.getRecommendationsByType('lunch');
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '午餐推薦');
    recommendationType = "午餐推薦";
  } else if (prompt.includes('晚餐')) {
    const recommendations = foodSystem.getRecommendationsByType('dinner');
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '晚餐推薦');
    recommendationType = "晚餐推薦";
  } else if (prompt.includes('療癒') || prompt.includes('舒適')) {
    const recommendations = foodSystem.getRecommendationsByType('comfort');
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '療癒美食');
    recommendationType = "療癒美食";
  } else {
    const recommendations = foodSystem.getRandomRecommendations();
    fallbackResponse = foodSystem.generateRecommendationText(recommendations, '隨機推薦');
    recommendationType = "隨機推薦";
  }
  
  // 本地推薦已經是條列式格式，直接使用
  const enhancedResponse = fallbackResponse;
  
  // 模擬串流輸出
  if (websocket) {
    const words = enhancedResponse.split('');
    for (const char of words) {
      await new Promise(resolve => setTimeout(resolve, 15)); // 模擬打字效果
      websocket.send(JSON.stringify({ type: 'chunk', delta: char }));
    }
  } else {
    console.log(enhancedResponse);
  }
  
  return enhancedResponse;
}

// 主程式執行（用於測試）
async function main() {
  const userPrompt = process.argv[2] || "請推薦一些健康的午餐選擇";
  console.log('用戶需求:', userPrompt);
  await generatePersonalizedRecommendation(userPrompt);
}

// 如果直接執行此文件
if (process.argv[1].endsWith('foodRecommendation.js')) {
  main();
} 