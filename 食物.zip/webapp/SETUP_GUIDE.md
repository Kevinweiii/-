# 🚀 智能食物推薦系統設置指南

## 📋 系統要求

- Node.js (版本 14 或以上)
- npm (Node Package Manager)
- Azure OpenAI 資源 (推薦但非必需)

## 🔧 快速設置

### 1. 安裝依賴
```bash
npm install
```

### 2. Azure OpenAI 配置

#### 創建 .env 文件
在項目根目錄創建 `.env` 文件並添加以下配置：

```env
# Azure OpenAI 配置
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/
AZURE_OPENAI_KEY=your_azure_openai_key_here
AZURE_OPENAI_DEPLOYMENT_NAME=your_deployment_name_here

# 服務器端口（可選）
PORT=3000
```

#### Azure OpenAI 參數說明
- `AZURE_OPENAI_ENDPOINT`: 您的 Azure OpenAI 資源端點
- `AZURE_OPENAI_KEY`: API 金鑰
- `AZURE_OPENAI_DEPLOYMENT_NAME`: 部署的模型名稱

### 3. 啟動服務器
```bash
npm start
```

或直接運行：
```bash
node server/server.js
```

### 4. 訪問應用程序
打開瀏覽器訪問：`http://localhost:3000`

## 🎯 無 Azure OpenAI 配置的使用方式

如果您沒有 Azure OpenAI 配置，系統仍然可以運行：

1. **本地推薦引擎**：系統會自動使用內建的食物推薦數據庫
2. **豐富的推薦選項**：包含早餐、午餐、晚餐等各類推薦
3. **營養資訊**：提供熱量、製作時間、食材等詳細資訊

## 🔍 功能測試

### 測試食物推薦功能
1. 點擊 "🍽️ 推薦美食" 按鈕
2. 選擇任一推薦類型
3. 查看系統生成的推薦結果

### 測試自然語言交互
在對話框中輸入：
- "推薦一些健康的午餐"
- "我想吃點快速的料理"
- "給我一些療癒的美食"

### API 測試
```bash
# 測試系統健康狀態
curl http://localhost:3000/health

# 測試食物推薦 API
curl http://localhost:3000/api/food-recommendations/random
curl http://localhost:3000/api/food-recommendations/healthy
```

## 🐛 常見問題

### Q1: 服務器無法啟動
**解決方案：**
1. 檢查 Node.js 是否正確安裝
2. 運行 `npm install` 確保依賴已安裝
3. 檢查端口 3000 是否被其他程序佔用

### Q2: Azure OpenAI 連接錯誤
**解決方案：**
1. 確認 `.env` 文件配置正確
2. 檢查 Azure OpenAI 資源是否正常運行
3. 驗證 API 金鑰和端點是否有效
4. 如果配置有誤，系統會自動使用本地推薦引擎

### Q3: 推薦結果不顯示
**解決方案：**
1. 檢查瀏覽器控制台是否有錯誤
2. 確認 WebSocket 連接正常
3. 嘗試重新載入頁面

## 📊 系統架構

```
webapp/
├── public/                 # 前端文件
│   ├── index.html         # 主要介面
│   └── iotDevice.js       # IoT 設備腳本
├── server/                # 後端服務器
│   └── server.js          # 主服務器文件
├── foodRecommendation.js  # 食物推薦系統
├── callAzureOpenAI.js     # Azure OpenAI 調用
├── package.json           # 項目配置
└── .env                   # 環境變數 (需要創建)
```

## 🌟 功能亮點

- ✅ **智能推薦**：6種推薦類型 + 5種快速選項
- ✅ **即時回應**：WebSocket 串流技術
- ✅ **備選方案**：本地推薦引擎確保可用性
- ✅ **詳細資訊**：營養、熱量、製作時間
- ✅ **響應式設計**：支援各種設備
- ✅ **API 接口**：RESTful API 支援

## 🔐 安全注意事項

1. **API 金鑰保護**：
   - 不要將 `.env` 文件提交到版本控制
   - 定期更換 Azure OpenAI API 金鑰
   
2. **網路安全**：
   - 在生產環境中使用 HTTPS
   - 設置適當的 CORS 政策

## 📞 支援

如果您需要幫助：
1. 查看系統健康狀態：`GET /health`
2. 檢查控制台日誌
3. 參考 [食物推薦系統文檔](./FOOD_RECOMMENDATION_README.md)

---

**準備好享受智能美食推薦了嗎？🍽️✨**